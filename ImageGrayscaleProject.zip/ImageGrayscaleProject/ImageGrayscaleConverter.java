import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class ImageGrayscaleConverter {

    public static void main(String[] args) {
        try {
            String inputPath = "input.jpg";
            String grayOutputPath = "output_grayscale.jpg";
            String colorEffectOutputPath = "output_colored.jpg";

            BufferedImage image = ImageIO.read(new File(inputPath));
            BufferedImage grayImage = convertToGrayscale(image);
            ImageIO.write(grayImage, "jpg", new File(grayOutputPath));

            BufferedImage colorizedImage = applyColorEffect(grayImage);
            ImageIO.write(colorizedImage, "jpg", new File(colorEffectOutputPath));

            System.out.println("Images saved: grayscale and color-effect versions.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static BufferedImage convertToGrayscale(BufferedImage original) {
        int width = original.getWidth();
        int height = original.getHeight();
        BufferedImage grayscale = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color c = new Color(original.getRGB(x, y));
                int gray = (int)(0.3 * c.getRed() + 0.59 * c.getGreen() + 0.11 * c.getBlue());
                Color gColor = new Color(gray, gray, gray);
                grayscale.setRGB(x, y, gColor.getRGB());
            }
        }
        return grayscale;
    }

    public static BufferedImage applyColorEffect(BufferedImage grayImage) {
        int width = grayImage.getWidth();
        int height = grayImage.getHeight();
        BufferedImage colored = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color c = new Color(grayImage.getRGB(x, y));
                int gray = c.getRed();
                Color pseudoColor = new Color(gray, 255 - gray, gray / 2);
                colored.setRGB(x, y, pseudoColor.getRGB());
            }
        }
        return colored;
    }
}