import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;

public class ImageGrayscaleGUI extends JFrame {

    private JLabel imageLabel;
    private BufferedImage originalImage;
    private BufferedImage processedImage;

    public ImageGrayscaleGUI() {
        setTitle("Image Grayscale Converter");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        imageLabel = new JLabel("No image loaded", SwingConstants.CENTER);
        add(imageLabel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton openButton = new JButton("Open Image");
        JButton grayButton = new JButton("Convert to Grayscale");
        JButton colorButton = new JButton("Apply Color Effect");
        JButton saveButton = new JButton("Save Image");

        buttonPanel.add(openButton);
        buttonPanel.add(grayButton);
        buttonPanel.add(colorButton);
        buttonPanel.add(saveButton);
        add(buttonPanel, BorderLayout.SOUTH);

        openButton.addActionListener(e -> openImage());
        grayButton.addActionListener(e -> convertToGrayscale());
        colorButton.addActionListener(e -> applyColorEffect());
        saveButton.addActionListener(e -> saveImage());

        setVisible(true);
    }

    private void openImage() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            try {
                File file = fileChooser.getSelectedFile();
                originalImage = ImageIO.read(file);
                processedImage = null;
                showImage(originalImage);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error loading image.");
            }
        }
    }

    private void showImage(BufferedImage image) {
        if (image != null) {
            ImageIcon icon = new ImageIcon(image.getScaledInstance(imageLabel.getWidth(), imageLabel.getHeight(), Image.SCALE_SMOOTH));
            imageLabel.setIcon(icon);
            imageLabel.setText("");
        }
    }

    private void convertToGrayscale() {
        if (originalImage == null) return;
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        processedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color c = new Color(originalImage.getRGB(x, y));
                int gray = (int)(0.3 * c.getRed() + 0.59 * c.getGreen() + 0.11 * c.getBlue());
                Color gColor = new Color(gray, gray, gray);
                processedImage.setRGB(x, y, gColor.getRGB());
            }
        }
        showImage(processedImage);
    }

    private void applyColorEffect() {
        if (processedImage == null) return;
        int width = processedImage.getWidth();
        int height = processedImage.getHeight();
        BufferedImage colored = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color c = new Color(processedImage.getRGB(x, y));
                int gray = c.getRed();
                Color pseudoColor = new Color(gray, 255 - gray, gray / 2);
                colored.setRGB(x, y, pseudoColor.getRGB());
            }
        }
        processedImage = colored;
        showImage(processedImage);
    }

    private void saveImage() {
        if (processedImage == null) return;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Image As");
        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            try {
                File file = fileChooser.getSelectedFile();
                ImageIO.write(processedImage, "jpg", file);
                JOptionPane.showMessageDialog(this, "Image saved successfully!");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving image.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ImageGrayscaleGUI());
    }
}
