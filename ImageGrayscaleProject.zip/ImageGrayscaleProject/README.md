# Java Grayscale and Color Effect Converter using Swing

This is a Java-based image converter that:
- Converts color images to grayscale
- Applies a pseudo-color effect to grayscale images
- Adds extra GUI features using in-built Java Swing

## How to Run

1. Place your image as `input.jpg` in the project folder.
2. Compile:
   javac ImageGrayscaleConverter.java
3. Run:
   java ImageGrayscaleConverter

The grayscale and pseudo-colored images will be saved in the same directory.